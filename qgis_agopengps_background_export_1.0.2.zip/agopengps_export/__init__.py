# -*- coding: utf-8 -*-
"""QGIS plugin entry point."""

def classFactory(iface):
    from .agopengps_export import AgOpenGPSExportPlugin
    return AgOpenGPSExportPlugin(iface)
