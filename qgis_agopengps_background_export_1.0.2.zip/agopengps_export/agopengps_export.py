# -*- coding: utf-8 -*-
"""Export visible QGIS layers to AgOpenGPS BackPic.png / BackPic.Txt.

This plugin intentionally exports a static map background. It does not export
WMS features as vectors and does not modify AgOpenGPS field geometry files.
"""

import os
import re
import shutil
from datetime import datetime

from qgis.PyQt.QtCore import QSize, Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QAction,
    QCheckBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsMapRendererParallelJob,
    QgsMapSettings,
    QgsPointXY,
    QgsProject,
    QgsRectangle,
)


_FLOAT_RE = re.compile(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?")


def read_startfix(field_dir):
    """Read the WGS84 StartFix latitude/longitude from AgOpenGPS Field.txt."""
    field_file = os.path.join(field_dir, "Field.txt")
    if not os.path.isfile(field_file):
        raise ValueError("Field.txt was not found in this folder. Select an AgOpenGPS field folder.")

    with open(field_file, "r", encoding="utf-8-sig", errors="replace") as stream:
        lines = stream.readlines()

    for idx, line in enumerate(lines):
        if line.strip().lower().startswith("startfix"):
            for candidate in lines[idx + 1:idx + 5]:
                candidate = candidate.strip()
                if not candidate:
                    continue
                if candidate.startswith("$"):
                    break
                vals = _FLOAT_RE.findall(candidate)
                if len(vals) >= 2:
                    lat = float(vals[0])
                    lon = float(vals[1])
                    if -90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0:
                        return lat, lon
                    break
    raise ValueError(
        "Could not read the coordinates following StartFix in Field.txt. "
        "Check that you selected the correct AgOpenGPS field folder."
    )


def make_local_crs(latitude, longitude):
    """Create a local WGS84 equirectangular CRS centred on the AOG StartFix.

    AgOpenGPS stores BackPic bounds as local metre offsets from the field's
    StartFix. For normal field-sized areas, this local CRS closely matches that
    local east/north coordinate frame and avoids Web Mercator scale distortion.
    """
    proj = (
        "+proj=eqc "
        f"+lat_ts={latitude:.12f} +lat_0={latitude:.12f} "
        f"+lon_0={longitude:.12f} "
        "+datum=WGS84 +units=m +no_defs +type=crs"
    )
    crs = QgsCoordinateReferenceSystem()
    try:
        ok = crs.createFromProj(proj)
    except Exception as exc:
        raise RuntimeError("QGIS could not create the local coordinate reference system: {}".format(exc))
    if not ok or not crs.isValid():
        raise RuntimeError("Could not create the local coordinate reference system for AgOpenGPS export.")
    return crs


def sample_transformed_extent(rect, transform, samples_per_edge=30):
    """Transform many points around a canvas rectangle and return local bounds."""
    if rect.isEmpty() or rect.width() <= 0 or rect.height() <= 0:
        raise ValueError("The QGIS map extent is empty.")

    pts = []
    n = max(2, int(samples_per_edge))
    xmin, xmax = rect.xMinimum(), rect.xMaximum()
    ymin, ymax = rect.yMinimum(), rect.yMaximum()
    for i in range(n + 1):
        t = i / float(n)
        x = xmin + (xmax - xmin) * t
        y = ymin + (ymax - ymin) * t
        pts.extend((QgsPointXY(x, ymin), QgsPointXY(x, ymax),
                    QgsPointXY(xmin, y), QgsPointXY(xmax, y)))

    transformed = []
    for point in pts:
        transformed.append(transform.transform(point))

    xs = [p.x() for p in transformed]
    ys = [p.y() for p in transformed]
    local = QgsRectangle(min(xs), min(ys), max(xs), max(ys))
    if local.width() <= 0 or local.height() <= 0:
        raise ValueError("Could not determine the extent of the map to export.")
    return local


class ExportDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent or iface.mainWindow())
        self.iface = iface
        self.setWindowTitle("AgOpenGPS Background Export")
        self.setMinimumWidth(560)

        root = QVBoxLayout(self)
        intro = QLabel(
            "Export the current QGIS map view as an AgOpenGPS field background. "
            "All currently visible layers will be included, including WMS and satellite imagery. "
            "To georeference the background, the plugin reads StartFix from Field.txt."
        )
        intro.setWordWrap(True)
        root.addWidget(intro)

        form = QFormLayout()
        root.addLayout(form)

        folder_row = QWidget()
        folder_layout = QHBoxLayout(folder_row)
        folder_layout.setContentsMargins(0, 0, 0, 0)
        self.folder_edit = QLineEdit()
        self.folder_edit.setPlaceholderText(r"Example: C:\Users\User\Documents\AgOpenGPS\Fields\Field1")
        self.folder_edit.textChanged.connect(self._update_startfix)
        folder_button = QPushButton("Browse…")
        folder_button.clicked.connect(self._browse_folder)
        folder_layout.addWidget(self.folder_edit, 1)
        folder_layout.addWidget(folder_button)
        form.addRow("AgOpenGPS field folder:", folder_row)

        self.origin_label = QLabel("Select the field folder containing Field.txt")
        self.origin_label.setWordWrap(True)
        form.addRow("Field.txt / StartFix:", self.origin_label)

        self.width_spin = QSpinBox()
        self.width_spin.setRange(500, 7000)
        self.width_spin.setSingleStep(250)
        self.width_spin.setValue(3000)
        self.width_spin.setSuffix(" px wide")
        form.addRow("Image resolution:", self.width_spin)

        self.visible_only = QCheckBox("Export only layers currently visible in the QGIS map")
        self.visible_only.setChecked(True)
        self.visible_only.setEnabled(False)
        root.addWidget(self.visible_only)

        warning = QLabel(
            "Close AgOpenGPS or at least close the current field before exporting. "
            "If BackPic.png / BackPic.Txt already exist, backup copies will be created. "
            "The export changes only the background map, not field boundaries or guidance lines."
        )
        warning.setWordWrap(True)
        warning.setStyleSheet("color: #9a5b00;")
        root.addWidget(warning)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        self.export_button = QPushButton("Export to AgOpenGPS")
        self.export_button.setDefault(True)
        self.export_button.clicked.connect(self.accept)
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        buttons.addWidget(self.export_button)
        buttons.addWidget(cancel_button)
        root.addLayout(buttons)

    def _browse_folder(self):
        folder = QFileDialog.getExistingDirectory(
            self, "Select AgOpenGPS field folder", self.folder_edit.text().strip()
        )
        if folder:
            self.folder_edit.setText(folder)

    def _update_startfix(self, _text=None):
        folder = self.folder_edit.text().strip()
        if not folder or not os.path.isdir(folder):
            self.origin_label.setText("Select a field folder containing Field.txt")
            return
        try:
            lat, lon = read_startfix(folder)
            self.origin_label.setText("{:.9f}, {:.9f}".format(lat, lon))
            self.export_button.setEnabled(True)
        except Exception as exc:
            self.origin_label.setText(str(exc))
            self.export_button.setEnabled(False)

    def values(self):
        return self.folder_edit.text().strip(), self.width_spin.value()


class AgOpenGPSExportPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        self.action = QAction("Export background map to AgOpenGPS…", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&AgOpenGPS Export", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu("&AgOpenGPS Export", self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None

    def run(self):
        dlg = ExportDialog(self.iface)
        # QGIS 4 uses Qt 6, where QDialog.exec_() was removed in favour of exec().
        # Keep compatibility with older QGIS/PyQt builds as well.
        if hasattr(dlg, "exec"):
            dialog_result = dlg.exec()
        else:
            dialog_result = dlg.exec_()
        accepted = (
            QDialog.DialogCode.Accepted
            if hasattr(QDialog, "DialogCode")
            else QDialog.Accepted
        )
        if dialog_result != accepted:
            return
        field_dir, width = dlg.values()
        try:
            result = self._export(field_dir, width)
            QMessageBox.information(
                self.iface.mainWindow(),
                "AgOpenGPS export completed",
                "Background map exported.\n\n"
                "PNG: {} x {} px\n"
                "BackPic.png: {}\n"
                "BackPic.Txt: {}\n\n"
                "Backup copies (if previous files existed) are saved in the same folder."
                .format(result["width"], result["height"], result["png"], result["txt"]),
            )
        except Exception as exc:
            QMessageBox.critical(
                self.iface.mainWindow(), "AgOpenGPS export error", str(exc)
            )

    def _export(self, field_dir, requested_width):
        if not os.path.isdir(field_dir):
            raise ValueError("The selected AgOpenGPS field folder does not exist.")
        lat0, lon0 = read_startfix(field_dir)

        canvas = self.iface.mapCanvas()
        project = QgsProject.instance()
        source_settings = canvas.mapSettings()
        source_crs = source_settings.destinationCrs()
        if not source_crs.isValid():
            raise ValueError("The QGIS map has no valid coordinate reference system.")

        local_crs = make_local_crs(lat0, lon0)
        transform = QgsCoordinateTransform(source_crs, local_crs, project)
        # Method is available in newer QGIS builds; keep compatibility with QGIS 3.22+.
        if hasattr(transform, "setBallparkTransformsAreAppropriate"):
            transform.setBallparkTransformsAreAppropriate(True)
        local_extent = sample_transformed_extent(canvas.extent(), transform)

        # AgOpenGPS's geo-background loader only accepts local map edges within
        # +/- 4000 m of the field origin (the same validation as its map editor).
        if any(abs(v) > 4000 for v in (
            local_extent.xMinimum(), local_extent.xMaximum(),
            local_extent.yMinimum(), local_extent.yMaximum()
        )):
            raise ValueError(
                "The map extent is more than 4000 m from StartFix in Field.txt.\n"
                "The AgOpenGPS BackPic georeferencing format limits map edges to "
                "±4000 m from the field origin. Zoom to the required field and try again."
            )

        aspect = local_extent.width() / local_extent.height()
        width = int(requested_width)
        height = max(250, int(round(width / aspect)))
        if width * height > 15_000_000:
            height = max(250, int(15_000_000 / width))
            # Keep aspect ratio by reducing width if necessary.
            width = max(500, min(width, int(height * aspect)))
            height = max(250, int(round(width / aspect)))
        if width * height > 15_000_000:
            raise ValueError("The selected resolution exceeds the safe 15-megapixel limit.")

        layers = source_settings.layers()
        if not layers:
            raise ValueError("There are no visible layers in the QGIS map to export.")

        settings = QgsMapSettings()
        settings.setLayers(layers)
        settings.setDestinationCrs(local_crs)
        settings.setTransformContext(project.transformContext())
        settings.setExtent(local_extent)
        settings.setOutputSize(QSize(width, height))
        settings.setOutputDpi(source_settings.outputDpi())
        settings.setBackgroundColor(QColor(255, 255, 255))
        settings.setFlags(source_settings.flags())

        job = QgsMapRendererParallelJob(settings)
        job.start()
        job.waitForFinished()
        image = job.renderedImage()
        if image.isNull():
            raise RuntimeError(
                "QGIS could not render the map image. Check whether the WMS/satellite layers are available and try again."
            )

        png_path = os.path.join(field_dir, "BackPic.png")
        txt_path = os.path.join(field_dir, "BackPic.Txt")
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backups = []
        for path in (png_path, txt_path):
            if os.path.isfile(path):
                backup = path + ".backup_" + stamp
                shutil.copy2(path, backup)
                backups.append(backup)

        temp_png = os.path.join(field_dir, "BackPic_export_tmp.png")
        temp_txt = os.path.join(field_dir, "BackPic_export_tmp.Txt")
        if not image.save(temp_png, "PNG"):
            raise RuntimeError("Could not write the PNG image to the AgOpenGPS field folder.")

        # AgOpenGPS BackPic.Txt order: $BackPic, georeferenced flag,
        # easting max, easting min, northing max, northing min.
        values = [
            local_extent.xMaximum(),
            local_extent.xMinimum(),
            local_extent.yMaximum(),
            local_extent.yMinimum(),
        ]
        with open(temp_txt, "w", encoding="ascii", newline="\n") as stream:
            stream.write("$BackPic\n")
            stream.write("True\n")
            for value in values:
                stream.write("{:.9f}\n".format(value))

        os.replace(temp_png, png_path)
        os.replace(temp_txt, txt_path)

        return {
            "png": png_path,
            "txt": txt_path,
            "width": image.width(),
            "height": image.height(),
            "backups": backups,
        }
