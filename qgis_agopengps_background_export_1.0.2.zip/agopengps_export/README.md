# AgOpenGPS Background Export for QGIS

Export the current QGIS map canvas to an AgOpenGPS field background. The export includes the rendered appearance of visible layers, including WMS layers, satellite imagery, and visible vector layers.

## Features

- Creates `BackPic.png` from the current QGIS map canvas.
- Reads the field origin (`StartFix`) latitude and longitude from the selected AgOpenGPS `Field.txt`.
- Creates `BackPic.Txt` with the local map bounds used by AgOpenGPS.
- Creates timestamped backups before replacing existing `BackPic.png` or `BackPic.Txt` files.
- Does not modify `Field.txt`, `Boundary.txt`, `ABLines.txt`, or other field data files.

## Installation

1. In QGIS, open **Plugins → Manage and Install Plugins… → Install from ZIP**.
2. Select `qgis_agopengps_background_export_1.0.2.zip`.
3. Enable **AgOpenGPS Background Export**.
4. Open your QGIS project and enable the layers you want in the background, such as satellite imagery, a drainage WMS layer, and vector overlays.
5. Zoom to the field or area you want to display in AgOpenGPS.
6. Close the field in AgOpenGPS before exporting (recommended).
7. In QGIS, select **Plugins → AgOpenGPS Export → Export background map to AgOpenGPS…** and choose the AgOpenGPS field folder containing `Field.txt`.
8. Choose the output image width and click **Export to AgOpenGPS**.

## Important notes

- The export is a static image, not live WMS data or vector geometry. Re-export to refresh the background.
- WMS or satellite layers that are unavailable or have not rendered will not appear in the exported image.
- Backups are stored in the same field folder and include a timestamp in their filenames.
- Test with a copy of an AgOpenGPS field first, and confirm that the background aligns with the field boundary. The plugin uses a local coordinate reference system centred on the `StartFix` location in `Field.txt`.
- The AgOpenGPS background format limits all map edges to within ±4000 m of the field origin. Export is cancelled if the selected map extent exceeds this range.
- Maximum output image size is limited to 15 megapixels to avoid excessive memory use.

## Version 1.0.2

- Changed all plugin UI text, error messages, metadata, and documentation to English.
- Retained the QGIS 4 / Qt 6 dialog compatibility fix using `exec()` with a fallback for older Qt/PyQt versions.
